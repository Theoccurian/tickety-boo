"""
Runs after the news robot inside GitHub Actions.

- Approval mode (auto_publish: false): every new article becomes its own pull request.
  Merge it to publish, close it to throw it away.
- Auto mode (auto_publish: true): new articles are published straight away.
Also tidies away review requests that have sat unanswered for too long.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import tempfile

from common import ARTICLES_DIR, NEW_ARTICLES_FILE, PHOTO_UPDATES_FILE, PHOTOS_DIR, SCORE_UPDATES_FILE, load_config, load_json

LABEL = "new-article"
PHOTO_LABEL = "new-photo"


def run(*cmd: str, check: bool = True) -> str:
    print("$ " + " ".join(cmd), flush=True)
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.stdout.strip():
        print(res.stdout.strip())
    if res.returncode != 0:
        print(res.stderr.strip())
        if check:
            raise SystemExit(f"Command failed: {' '.join(cmd)}")
    return res.stdout


def push_main() -> None:
    for _ in range(3):
        run("git", "pull", "--rebase", "--autostash", "origin", "main", check=False)
        if subprocess.run(["git", "push", "origin", "HEAD:main"]).returncode == 0:
            return
    raise SystemExit("Couldn't push to main.")


def existing(*paths: str) -> list[str]:
    from common import ROOT
    return [p for p in paths if (ROOT / p).exists()]


def has_changes(*paths: str) -> bool:
    return bool(run("git", "status", "--porcelain", "--", *paths).strip())


def photo_section(a: dict, branch: str = "") -> str:
    img = a.get("image")
    if not img:
        return "**Photo:** none found that clearly shows the right thing, so it'll use the sunrise illustration.\n"
    where = "Instagram and the website" if img.get("instagram_ok") else "the website only (its licence doesn't allow the Instagram crop)"
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    src = f"https://raw.githubusercontent.com/{repo}/{branch}/content/photos/{img['file']}" if repo and branch and img.get("file") else img["url"]
    return (f'<img src="{src}" alt="" width="480">\n\n'
            f'**Photo:** {img["caption"]}  \n'
            f'Credit: {img["credit"]} / [{img["library"]}]({img["source_page"]}), {img["licence"]}. Used on {where}.\n\n'
            "*Wrong photo?* Open **Files changed**, edit the article file and delete the whole `image:` section, then merge.\n")


def photo_pr_body(u: dict, branch: str) -> str:
    return f"""## Photo for a published story

**{u['title']}**

{photo_section(u, branch)}
### What to do
- **Use this photo:** tap **Merge pull request**, then **Confirm merge**. The story updates within a few minutes.
- **Not right:** tap **Close pull request**. The story keeps its illustration, and this story won't be tried again.
"""


def pr_body(a: dict, cat_names: dict, branch: str = "") -> str:
    return f"""## {a['title']}

*{a['dek']}*

{photo_section(a, branch)}

**Section:** {cat_names.get(a['category'], a['category'])}  |  **Where:** {a['location']}

**In brief:**
{chr(10).join('- ' + p for p in a.get('key_points', []))}

---

{a['body']}

---

**Instagram mentions:** {(' '.join('@' + str(h) for h in a.get('instagram_tags') or [])) or 'none found'}  
*(Found on each organisation's own website. To change them, edit the `instagram_tags:` list in the article file, or delete it.)*

**Instagram caption:**

> {a.get('instagram_caption', '').replace(chr(10), chr(10) + '> ')}

---

**Original story:** [{a['source_title']}]({a['source_url']}) ({a['source_name']})

### What to do
- **Publish it:** tap **Merge pull request**, then **Confirm merge**. It's on the website within a few minutes, then joins the Instagram queue.
- **Bin it:** tap **Close pull request**.
- **Tweak the wording or caption first:** open **Files changed**, tap the **⋯** menu on the file, choose **Edit file**, save, then merge.

Worth a quick look at the original story to check the facts match.
"""


def close_stale(days: int) -> None:
    prs = []
    for label in (LABEL, PHOTO_LABEL):
        out = run("gh", "pr", "list", "--label", label, "--state", "open",
                  "--json", "number,createdAt", "--limit", "100", check=False)
        try:
            prs += json.loads(out or "[]")
        except json.JSONDecodeError:
            pass
    cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)
    for pr in prs:
        created = dt.datetime.fromisoformat(pr["createdAt"].replace("Z", "+00:00"))
        if created < cutoff:
            run("gh", "pr", "close", str(pr["number"]), "--delete-branch",
                "--comment", f"Closed automatically after {days} days without review.", check=False)


def main() -> None:
    cfg = load_config()
    pub = cfg["publishing"]
    cat_names = {c["slug"]: c["name"] for c in cfg["categories"]}
    new = load_json(NEW_ARTICLES_FILE, [])

    run("git", "config", "user.name", "good-news-bot")
    run("git", "config", "user.email", "41898282+github-actions[bot]@users.noreply.github.com")

    if pub.get("auto_publish"):
        if has_changes("content", "data/seen.json", "data/photo_checked.json", "data/feed_status.json"):
            run("git", "add", *existing("content", "data/seen.json", "data/photo_checked.json", "data/feed_status.json"))
            run("git", "commit", "-m", f"Publish {len(new)} new article(s)")
            push_main()
        return

    # 1. Save the "already seen" list to the main branch so stories aren't picked twice.
    # Ratings and hook lines added to recent published stories go straight onto the main branch.
    rated = [str(ARTICLES_DIR / f) for f in load_json(SCORE_UPDATES_FILE, []) if (ARTICLES_DIR / f).exists()]
    if has_changes("data/seen.json", "data/photo_checked.json", "data/feed_status.json") or rated:
        run("git", "add", *existing("data/seen.json", "data/photo_checked.json", "data/feed_status.json"), *rated)
        run("git", "commit", "-m", "Update list of stories already considered" + (f"; ratings for {len(rated)} story/stories" if rated else ""))
        push_main()

    # 2. One pull request per article, so each can be approved or binned on its own.
    if new:
        run("gh", "label", "create", LABEL, "--color", "FFC23D",
            "--description", "Article waiting for approval", "--force", check=False)
    for a in new:
        branch = f"article/{a['file'][:-3]}"
        run("git", "switch", "-c", branch)
        run("git", "add", str(ARTICLES_DIR / a["file"]))
        photo = (a.get("image") or {}).get("file")
        if photo and (PHOTOS_DIR / photo).exists():
            run("git", "add", str(PHOTOS_DIR / photo))
        run("git", "commit", "-m", f"New article: {a['title']}")
        run("git", "push", "-u", "origin", branch)
        with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False, encoding="utf-8") as f:
            f.write(pr_body(a, cat_names, branch))
        run("gh", "pr", "create", "--base", "main", "--head", branch,
            "--title", a["title"], "--body-file", f.name, "--label", LABEL, check=False)
        run("git", "switch", "main")

    # 3. Photos found for stories that are already published: one pull request each.
    updates = load_json(PHOTO_UPDATES_FILE, [])
    if updates:
        run("gh", "label", "create", PHOTO_LABEL, "--color", "7FC8A9",
            "--description", "Photo for a published story, waiting for approval", "--force", check=False)
    for u in updates:
        branch = f"photo/{u['file'][:-3]}"
        run("git", "switch", "-c", branch)
        run("git", "add", str(ARTICLES_DIR / u["file"]), str(PHOTOS_DIR / u["image"]["file"]))
        run("git", "commit", "-m", f"Add photo: {u['title']}")
        run("git", "push", "-u", "origin", branch)
        with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False, encoding="utf-8") as f:
            f.write(photo_pr_body(u, branch))
        run("gh", "pr", "create", "--base", "main", "--head", branch,
            "--title", f"Photo: {u['title']}", "--body-file", f.name, "--label", PHOTO_LABEL, check=False)
        run("git", "switch", "main")

    close_stale(int(pub.get("discard_unreviewed_after_days", 5)))


if __name__ == "__main__":
    main()
